                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1698397
Microswitch filament runout sensor by eussrh is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Here is a simple filament runout sensor.  I was going to use an optical sensor, but I print using clear filament sometimes, and wasn't sure how it would work.  In any case I had several of these microswitches laying around and decided to use them.  These have a flag, but no roller (https://www.amazon.com/gp/product/B00UBWSMKC/ref=oh_aui_search_detailpage?ie=UTF8&psc=1).  Note that I slightly bent down the end of the flag, so that the filament would slide either way, but you want the primary direction to be so that it goes with the flag.  I put a mark on the outside of the assembly so I would know which way to the filament goes.  To secure the two haves, you need 3x M2x12mm bolts and nuts.  I created versions for 3mm and 1.75mm filament.  It will clamp onto entry or exit tubing. I assumed 6mm tubing for 3mm filament and 4mm tubing for 1.75mm filament.

# Print Settings

Printer Brand: LulzBot
Printer: Mini
Rafts: No
Supports: No
Resolution: .2
Infill: 20%

Notes: 
Nothing special required.  Miles and miles of filament passing thru could eventually grind down the channel, so I guess tougher is better.  I used HIPS.