                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2065439
CL 260 Ultimaker UpGrades by astfaellergerald is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

CL 260 Ultimaker UpGrades

Upgrade Teile für den CL 260 und ähnliche Drucker
Die Seite ist im Aufbau u. kann noch verändert werden. 
für Anregungen oder Beiträge bin ich dankbar.

JETZT NEU! kompakter u- leichter Druckkopf für 11mm, 12mm und 15mm- Gleitlager, mit nur einem Filamentkühler, sehr leichte u. kompakte Bauweise mit soliden Befestigungsmöglichkeiten mittels 3M Schrauben u. Muttern u. oben zusätzliche Befestigungsmöglichkeiten beispielsweise für LED- Beleuchtung oder andere Filamentzuführung. Der Filamentkühler kommt mit einem Fan aus was die zu bewegende Masse minimiert und schnellere Druckgeschwindigkeit ermögllicht:

Bei den Riemenspanner für 11mm Lager ist ein "Halbring" dabei, (damit man den Druckkopf mitsamt den beiden Wellen einfach mal nach oben rausheben kann) und um das diesen kommen noch kleine Kabelbinder rum, damit ist alles stramm festgezurrt und es wackelt nichts. Durch die gebogene Riemenführung beim verstellbaren Teil bleiben die Abmessungen gering und es geht  kein Bauraum verloren.

Für den Bau braucht man einige 3M Schauben und Muttern unterschiedlicher Längen

Druckerhaube: 
Die Maße für die Acrylglasplatten 2mm der Zeichnung entnehmen´.
für Größenänderung müssen die Leisten "170131_Haube02-P1-a bis -g" nur in der Länge entsprechend skaliert werden.
Das 2mm Acrylglas hab ich beidseitig mit dem Tapetenmesser tief eingeritzt, dann läßt sich das sauber brechen. 
Ich verwende es auch als abnehmbare Seitenwände, befestigt mit den Hammerschrauben (siehe oben). 
Es gibt davon Platten mit z. B. 100 X 50 cm, somit braucht man nur jeweils die Breite abschneiden. Das ganze eignet sich gut zum ABS- Drucken, weil durch das "Gehäuse" die für ABS- Druck nötige Umgebungstemperatur von ca. 55° gegeben ist, so daß keine Verwerfungen entstehen.

Mehr Informationen gibt es hier: 
https://www.facebook.com/groups/829299173846060/
http://www.thingiverse.com/joecool92/collections/cl260
https://www.thingiverse.com/thing:1800495

Neu! Teile für direkt extruder von flexibler Welle angetrieben (kompatibel mit compact head 11mm):
https://www.thingiverse.com/thing:2691910


----------------------------------------------------
CL 260 Ultimaker UpGrades

Upgrade parts for the CL 260 and similar printers
The page is under construction and can still be changed.
For suggestions or contributions I am grateful.

NOW NEW! Compact and light print head for 11mm, 12mm and 15mm slide bearings, with only one filament cooler, very light and compact design with solid mounting possibilities by means of 3M screws and nuts and above additional mounting possibilities for example for LED lighting or other filament feeding. The filament cooler comes with a fan which minimizes the mass to be moved and enables faster printing speed:

With the belt tensioner for 11mm bearing is a "Halbring" thereby, (so that the print head with the two shafts can simply rausmorgen) and around this come still small cable ties, so everything is tightly tied and it wobbles nothing. Due to the curved belt guide with the adjustable part, the dimensions remain small and no space is lost.

For the construction you need some 3M screws and nuts of different lengths

Printer hood:
Measure the dimensions for the acrylic glass plates 2mm from the drawing.
For size change, the strips "170131_Haube02-P1-a to -g" have to be scaled only in length.
The 2mm acrylic glass I have on both sides with the wallpaper knife deeply carved, then the clean can break.
I also use it as removable side walls, fixed with the hammer screws (see above).
There are plates with, for example, 100 x 50 cm, so you only need to cut the width. The whole is well suited for ABS printing because the ambient temperature of approx. 55 ° required for ABS pressure is provided by the "housing" so that no warping occurs.

Here you will find more information:
Https://www.facebook.com/groups/829299173846060/
Http://www.thingiverse.com/joecool92/collections/cl260
https://www.thingiverse.com/thing:1800495

New! Parts for direct extruder driven by flexible shaft (compatible with compact head 11mm): https://www.thingiverse.com/thing:2691910