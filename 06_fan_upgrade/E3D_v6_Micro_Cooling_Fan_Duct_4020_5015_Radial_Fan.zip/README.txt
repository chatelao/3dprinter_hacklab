                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2469775
E3D v6 Micro Cooling Fan Duct (4020/5015 Radial Fan) by graham01 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Small and unobtrusive fan duct for the E3D-v6 hotend, for use with either a 4020 or 5015 radial fan.

I like the fangs, but I find them a bit too big and in the way, so I designed this one that has a similar dual exhaust profile to the 'Radial Fan Fang' by Lion4H.

I have experimented with a few different fans (single/dual 3030, 4040, etc) and exhaust profiles and found this configuration to give the best results.

There are 2 stl's available, for left-handed and right-handed versions, however as of writing this I have only experimented with the right-handed version.

No supports needed, just orient it so the front face is on the build plate (stl's should already be oriented the correct way)

Thanks for looking, hope people find this useful!

# Print Settings

Printer: Creality CR-10
Rafts: No
Supports: No
Resolution: 0.15
Infill: 10%