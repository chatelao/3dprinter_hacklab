                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1551419
Fan duct for LOGresse (Prusa Steel) carriage and radial fan by phil38 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This new fan duct for a radial fan and single extruder aims to blow efficiently around the deposited material, while keeping view and acces to the front part of the nozzle.
The efficiency is partly due to several thin walls that guide and distribute the air flow along the fan duct. You can see their shapes on the last picture (cut view from CAD model)
It has been designed to be mounted on the x-carriage of the LOGresse (https://www.logre.eu/wiki/Logresse/en)
There have been several versions. On version 4b the fan is fixed by two screws M3.
Version 5b seems to be simpler and more efficient than previous ones, with only one screw (probably enough while the output side of the fan is inserted in the fan duct).

You can also try to open the crenels, or not. (it has been done on the picture for the green version).

The "wedge" (not sure it is the good translation in English) may be put between the carriage and the fan duct support, in order to obtain a different lateral position of the fan duct. Useful if the hot end is mounted in a non symetrical way. As the model is 1mm thick, you should just print it horizontally with a vertical scale factor corresponding to the gap you want to keep in the assembly.

Finally, if you need (or want) to mount your fan on the left side of the carriage, print the parts after mirroring! The fan will still fit perfectly.