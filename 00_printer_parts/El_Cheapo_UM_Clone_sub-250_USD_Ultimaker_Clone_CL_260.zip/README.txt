                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2336253
El Cheapo UM Clone (sub-250 USD Ultimaker Clone) CL 260 by samella is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

<b>If you like what you see consider using my referral link on Banggood. Thanks!
12% off on FPV Stuff: https://goo.gl/39KJyG. 
</b>

Update July 26: Did some tweaks on XY Axis Mounts and Clamps

Update July 23: New Pictures! I've changed Hotend mount to this one: https://www.thingiverse.com/thing:2004928. 

Update May 24: I have tagged this thing as WORK IN PROGRESS. Not because the printer is not working in its current state (actually it's working quite awesome!) but because I'm updating a couple of parts to make them more appealing (XY Axis Holder) or more functional (all Endstops)

This is a sub-250 USD Ultimaker Clone.

Total Costs are below 250 USD or 220 EUR, beating the price tag of the popular CL 260 UM-Clone. I've made a couple of design changes - see pictures for reference. And despite it's low price point the printer works exceptionally accurate.

Note: I'm still tweaking a thing or two, so expect changes to printed parts over time. 

# Bill of Materials - 95% complete, excluding Vitamins

2020 Aluminium Profiles, Type B Slot 6: 4x 500mm, 8x 340mm, 2x 250mm (https://us.misumi-ec.com/ or http://motedis.com)
2040 Aluminium Profile, Type B Slot 6: 1x 230mm  (https://us.misumi-ec.com/ or http://motedis.com)
Corner Brackets (2 Packs): https://goo.gl/i4RSJy
M4 Sliding Nuts (1 Pack): https://goo.gl/xdTAWo
M3 Sliding Nuts (1 Pack): https://goo.gl/pQzvqb
Precision Rods: https://goo.gl/qAniuy
(2x 300mm need to cut to 280mm, 4x 380mm) and
https://goo.gl/M3tiO6 (2x 500mm)
Collars (4x): https://goo.gl/euJcit

Heated Bed (1x): https://goo.gl/msQqgc
Thermistor (1x): https://goo.gl/sIyNPY
Springs for Extruder and Heated Bed: (1 Pack) http://goo.gl/d0Y87G
Extruder Gear (1x): https://goo.gl/Wud4bf
Teflon Tube and Pushfit (1x): https://goo.gl/I6ex9A
Shaft Coupling 5mm/8mm (1x): https://goo.gl/EEh3Z2
Hotend (1x): https://goo.gl/GYA4Ct

Linear Bearings for Z Axis (2x): https://goo.gl/NUX4NX
608zz Bearing (1 Pack): https://goo.gl/ZjNMzL
Sinter Bushing (2 Packs): https://goo.gl/9qJHE1

GT2 Pulleys (2x, 20 Teeth): https://goo.gl/nGRLVg
GT2 Pulleys for 8mm Rods (10x, 20 Teeth): https://goo.gl/3oZQV4
GT2 Timing Belt (1x): https://goo.gl/lCSE6E
Closed Loop Timing Belt 280mm (2x): https://goo.gl/r25AJ7

Electronics (RAMPS, Arduino, LCD, Stepper Drivers - 1x): https://goo.gl/hTaSCm
Stepper Motor for X/Y and Extruder (3x): https://goo.gl/l6GR59
Stepper Motor for Z Axis (1x): https://goo.gl/Oi0zzJ
Power Supply Socket (1x): https://goo.gl/98ujmm
Power Supply (1x): https://goo.gl/j2awx4

40mm Fan (2x): https://goo.gl/jpXFMC
30mm Fan (1x): https://goo.gl/1cK2F8
Endstop Switch (1 Pack): https://goo.gl/nVQorv

Cable Sleeves (1x 6mm): https://goo.gl/7lcqpt

# Additional Printed Parts

Extruder: https://www.thingiverse.com/thing:1325347
Hotend + Fan Mount: https://www.thingiverse.com/thing:2004928
XY Axis Corners: https://www.thingiverse.com/thing:2100073
PSU Cover: https://www.thingiverse.com/thing:1274955