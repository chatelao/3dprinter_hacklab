                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2851658
Better Z endstop for CL-260 ( XTLW2-extended, ultimaker clone) by kino90 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

# A better Z endstop for CL260 3d printer. 

I didn't like the original design, so I made my own. 

## Features 

* Adjustable Height
* Fixed position, cannot move freely (and miss endstop)

## Printing

Just print the "body" part with the rectangular hole facing up (no need for supports or nothing else, really easy print)

## BOM

* 3x m3 nut
* 1x m3x16 screw
* 1x m3x45 screw (or the original m3x40)

## Installation

Just fix the "body" part to the platform with the m3x16 screws and slide the m3x45 (or the original m3x40) from the bottom of the third hole. 

Insert a nut before and one after the "L" piece (see image) and tighten them to hold it in place. Slide the third nut in the rectangular hole of the "head" piece and lock it over the longest screw.

#### If you like the design you can *tip* me! A beer from a buddy is always welcome!

 

# Print Settings

Printer: XTLW2 Extended (CL-260)
Rafts: No
Supports: No
Resolution: 0.2
Infill: 30%

Notes: 
Print the cube with rectangular hole up. No supports needed.