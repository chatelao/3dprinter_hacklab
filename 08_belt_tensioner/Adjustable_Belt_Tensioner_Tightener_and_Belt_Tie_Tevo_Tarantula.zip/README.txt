                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1780636
Adjustable Belt Tensioner/Tightener and Belt Tie (Tevo Tarantula) by supasorn is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

*Update 11/5/18*: Added 1.5mm base to the thick version.
*Update 11/4/18*: Added a thick version (+2mm thickness).
*Update 3/11/17* : New hole, added fillet.
*Update 10/23/16* : increased thickness for screw holder and legs.

A simple, adjustable belt tensioner + a belt tie to replace the cable tie.
The tensioner requires an M3 screw. The screw hole is tight-fit and should provide more than enough tension to hold the screw. Designed to be printed at 100% scale.

Use higher wall line count (shells) & high infill for maximum strength. 

The calibration cube in 3rd photo was printed @0.1mm layer height with  *properly* tensioned belts and a Dual Z mod https://www.thingiverse.com/thing:2163949

sketchup/fusion360 file is attached in case adjustment is needed.



# Print Settings

Rafts: No
Supports: No
Resolution: 0.2
Infill: 50%